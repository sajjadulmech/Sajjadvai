/**
 * ClearTapLab Web Application Main Logic
 * Interactive Tools: Symptom Triage, Softener Sizing Calculator, Live Search & Article Reader
 */

document.addEventListener('DOMContentLoaded', () => {
  initSymptomTriage();
  initCalculator();
  initArticleGrid();
  initLiveSearch();
  initModalReader();
  initMobileDrawer();
});

/* ==========================================================================
   1. Interactive Symptom Diagnostic Triage Tool
   ========================================================================== */
const SYMPTOM_DATA = {
  sulfur: {
    title: "Rotten Egg / Sulfur Odor",
    cause: "Dissolved Hydrogen Sulfide gas (H₂S) from groundwater sulfur bacteria or water heater sacrificial magnesium anode rods.",
    epa: "Secondary Aesthetic Guideline: < 0.05 PPM (Odor detectable at 0.0005 PPM)",
    fix: "Air-Injection Oxidation (AIO) or Powered Titanium Anode Rod",
    articleId: 3,
    pillClass: "ctl-badge-warning",
    formula: "H₂S + 2O₂ ──► SO₄²⁻ + 2H⁺"
  },
  limescale: {
    title: "White Chalky Limescale & Fixture Crust",
    cause: "High concentration of dissolved Calcium (Ca²⁺) and Magnesium (Mg²⁺) carbonates exceeding 7 GPG (120 PPM).",
    epa: "No Health Limit; Plumbing Threshold > 7 GPG causes pipe scale & heater burnout",
    fix: "Ion-Exchange Water Softener or Salt-Free TAC Conditioner",
    articleId: 5,
    pillClass: "ctl-badge-warning",
    formula: "Ca²⁺ + 2HCO₃⁻ ──► CaCO₃↓ + H₂O + CO₂"
  },
  rust: {
    title: "Orange / Red Stains & Metallic Aftertaste",
    cause: "Dissolved clear-water ferrous iron (Fe²⁺) or precipitated red-water ferric iron (Fe³⁺) exceeding 0.3 PPM.",
    epa: "EPA Secondary Standard: 0.3 PPM (mg/L)",
    fix: "Air-Injection Oxidation (AIO) + 5µm Depth Sediment Filter",
    articleId: 6,
    pillClass: "ctl-badge-warning",
    formula: "4Fe²⁺ + O₂ + 10H₂O ──► 4Fe(OH)₃↓ + 8H⁺"
  },
  chlorine: {
    title: "Bleach Chemical Taste & Odor",
    cause: "Municipal disinfection residuals: Free Chlorine or Chloramines (chlorine + ammonia) and volatile disinfection byproducts (DBPs).",
    epa: "EPA Maximum Residual Disinfectant Level (MRDL): 4.0 PPM",
    fix: "Multi-Stage Catalytic Carbon Block or Under-Sink RO",
    articleId: 2,
    pillClass: "ctl-badge-pill",
    formula: "NH₂Cl + C* ──► NH₃ + C*O + Cl⁻"
  },
  acidic: {
    title: "Blue-Green Copper Stains & Pinhole Pipe Leaks",
    cause: "Corrosive acidic water (pH < 6.5) dissolving internal copper plumbing pipes and brass fittings.",
    epa: "EPA Secondary Guideline: pH 6.5 – 8.5 (Ideal: 7.2 – 7.8)",
    fix: "Calcite / Corosex Acid Neutralizing Media Tank",
    articleId: 13,
    pillClass: "ctl-badge-warning",
    formula: "CaCO₃ + 2H⁺ ──► Ca²⁺ + H₂O + CO₂"
  }
};

function initSymptomTriage() {
  const buttons = document.querySelectorAll('.ctl-symptom-btn');
  const resultCard = document.getElementById('triage-result-container');
  if (!buttons.length || !resultCard) return;

  buttons.forEach(btn => {
    btn.addEventListener('click', () => {
      buttons.forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      const symptomKey = btn.getAttribute('data-symptom');
      const data = SYMPTOM_DATA[symptomKey];

      if (data) {
        resultCard.innerHTML = `
          <div style="border-right: 1px solid var(--ctl-border); padding-right: 20px;">
            <div class="ctl-badge-pill ${data.pillClass}" style="margin-bottom: 8px;">Diagnosed Mechanism</div>
            <div class="ctl-result-title">${data.title}</div>
            <p style="font-size: 0.92rem; color: var(--ctl-text-muted); margin-bottom: 12px;"><strong>Likely Cause:</strong> ${data.cause}</p>
            <div style="font-family: var(--ctl-font-mono); font-size: 0.8rem; background: var(--ctl-bg-ice); padding: 8px 12px; border-radius: var(--ctl-radius-sm); color: var(--ctl-navy); margin-bottom: 10px;">
              <strong>Reaction:</strong> ${data.formula}
            </div>
            <div style="font-size: 0.82rem; color: #64748B;"><strong>Standard:</strong> ${data.epa}</div>
          </div>
          <div style="padding-left: 10px;">
            <div class="ctl-spec-box" style="margin: 0 0 16px;">
              <h4 style="margin-bottom: 4px;">Proven Engineering Solution:</h4>
              <p style="font-weight: 700; color: var(--ctl-navy); font-size: 1.05rem; margin: 0;">${data.fix}</p>
            </div>
            <button class="ctl-btn ctl-btn-primary ctl-btn-sm" onclick="openArticleModal(${data.articleId})" style="width: 100%;">
              Read Complete Engineering Diagnostic Guide ➔
            </button>
          </div>
        `;
      }
    });
  });
}

/* ==========================================================================
   2. Interactive Water Softener & RO Sizing Calculator
   ========================================================================== */
function initCalculator() {
  const peopleInput = document.getElementById('calc-people');
  const hardnessInput = document.getElementById('calc-hardness');
  const ironInput = document.getElementById('calc-iron');

  if (!peopleInput || !hardnessInput || !ironInput) return;

  function calculate() {
    const people = Math.max(1, parseInt(peopleInput.value) || 4);
    const hardnessGpg = Math.max(1, parseFloat(hardnessInput.value) || 10);
    const ironPpm = Math.max(0, parseFloat(ironInput.value) || 0);

    // Step 1: Daily Household Water Demand
    const dailyGallons = people * 75;

    // Step 2: Compensated Hardness
    const compensatedHardness = hardnessGpg + (ironPpm * 5);

    // Step 3: Daily Grains to remove
    const dailyGrains = dailyGallons * compensatedHardness;

    // Step 4: Weekly Grain Requirement (7 days) + 25% Reserve
    const rawWeeklyCapacity = dailyGrains * 7 * 1.25;

    // Standard tank sizing round-up
    let recommendedSize = 32000;
    let cuFt = 1.0;
    if (rawWeeklyCapacity <= 24000) { recommendedSize = 24000; cuFt = 0.75; }
    else if (rawWeeklyCapacity <= 32000) { recommendedSize = 32000; cuFt = 1.0; }
    else if (rawWeeklyCapacity <= 40000) { recommendedSize = 40000; cuFt = 1.25; }
    else if (rawWeeklyCapacity <= 48000) { recommendedSize = 48000; cuFt = 1.5; }
    else if (rawWeeklyCapacity <= 64000) { recommendedSize = 64000; cuFt = 2.0; }
    else if (rawWeeklyCapacity <= 80000) { recommendedSize = 80000; cuFt = 2.5; }
    else { recommendedSize = 96000; cuFt = 3.0; }

    // Update DOM
    document.getElementById('res-daily-gal').textContent = `${dailyGallons.toLocaleString()} GPD`;
    document.getElementById('res-comp-hard').textContent = `${compensatedHardness.toFixed(1)} GPG`;
    document.getElementById('res-daily-grains').textContent = `${Math.round(dailyGrains).toLocaleString()} Grains`;
    document.getElementById('res-target-cap').textContent = `${recommendedSize.toLocaleString()} Grains`;
    document.getElementById('res-resin-vol').textContent = `${cuFt} cu ft Resin Bed`;

    // 5-Year Salt Estimate ($8 per 40lb bag)
    const annualSaltBags = Math.round((dailyGrains * 365) / (2000 * 40)) + 6;
    const fiveYearSaltCost = annualSaltBags * 8 * 5;
    document.getElementById('res-salt-cost').textContent = `~$${fiveYearSaltCost} ($${(fiveYearSaltCost / (5 * 365)).toFixed(2)}/day)`;
  }

  [peopleInput, hardnessInput, ironInput].forEach(input => {
    input.addEventListener('input', calculate);
  });

  calculate();
}

/* ==========================================================================
   3. Dynamic Article Grid & Category Filter Tabs
   ========================================================================== */
function initArticleGrid() {
  const gridContainer = document.getElementById('articles-grid');
  const tabs = document.querySelectorAll('.ctl-tab-btn');
  if (!gridContainer || typeof CLEAR_TAP_ARTICLES === 'undefined') return;

  function renderArticles(filterCategory = 'all') {
    const filtered = filterCategory === 'all' 
      ? CLEAR_TAP_ARTICLES 
      : CLEAR_TAP_ARTICLES.filter(a => a.category === filterCategory);

    gridContainer.innerHTML = filtered.map(a => `
      <div class="ctl-article-card">
        <div>
          <div class="ctl-article-meta-top">
            <span class="ctl-badge-pill ${a.badgeClass}" style="font-size: 0.7rem;">${a.categoryLabel}</span>
            <span class="ctl-read-time">${a.readTime}</span>
          </div>
          <h3 class="ctl-article-title">${a.title}</h3>
          <p class="ctl-article-snippet">${a.excerpt}</p>
        </div>
        <button class="ctl-btn ctl-btn-outline ctl-btn-sm" onclick="openArticleModal(${a.id})" style="margin-top: 15px; width: 100%;">
          Read Complete Guide ➔
        </button>
      </div>
    `).join('');
  }

  tabs.forEach(tab => {
    tab.addEventListener('click', () => {
      tabs.forEach(t => t.classList.remove('active'));
      tab.classList.add('active');
      const cat = tab.getAttribute('data-category');
      renderArticles(cat);
    });
  });

  renderArticles('all');
}

/* ==========================================================================
   4. Modal Article Reader
   ========================================================================== */
function initModalReader() {
  window.openArticleModal = function(articleId) {
    if (typeof CLEAR_TAP_ARTICLES === 'undefined') return;
    const article = CLEAR_TAP_ARTICLES.find(a => a.id === articleId);
    if (!article) return;

    const modal = document.getElementById('article-modal');
    const modalBody = document.getElementById('modal-article-body');
    const modalContainer = modal ? modal.querySelector('.ctl-modal-container') : null;

    modalBody.innerHTML = article.contentHtml;
    if (modalContainer) {
      modalContainer.scrollTop = 0;
    }
    modal.classList.add('open');
    document.body.style.overflow = 'hidden';
  };

  window.closeArticleModal = function() {
    const modal = document.getElementById('article-modal');
    if (modal) {
      modal.classList.remove('open');
      document.body.style.overflow = '';
    }
  };

  // Close on Backdrop Click
  const modalBackdrop = document.getElementById('article-modal');
  if (modalBackdrop) {
    modalBackdrop.addEventListener('click', (e) => {
      if (e.target === modalBackdrop) {
        closeArticleModal();
      }
    });
  }

  // Close on ESC Key
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') {
      closeArticleModal();
      closeSearch();
      closeMobileDrawer();
    }
  });
}

/* ==========================================================================
   5. Live Instant Search Overlay
   ========================================================================== */
/**
 * Sanitize untrusted input strings before rendering into HTML.
 * Prevents Cross-Site Scripting (XSS) and unwanted HTML element injection.
 */
function escapeHtml(str) {
  if (!str) return '';
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}

function initLiveSearch() {
  const searchOverlay = document.getElementById('search-overlay');
  const searchInput = document.getElementById('search-query-input');
  const searchResults = document.getElementById('search-results-list');

  window.openSearch = function() {
    if (searchOverlay && searchInput) {
      searchOverlay.classList.add('open');
      searchInput.focus();
      document.body.style.overflow = 'hidden';
      performSearch('');
    }
  };

  window.closeSearch = function() {
    if (searchOverlay) {
      searchOverlay.classList.remove('open');
      document.body.style.overflow = '';
    }
  };

  function performSearch(query) {
    if (!searchResults || typeof CLEAR_TAP_ARTICLES === 'undefined') return;
    const cleanQ = query.trim().toLowerCase();

    const matches = CLEAR_TAP_ARTICLES.filter(a => {
      const tagMatch = Array.isArray(a.tags) 
        ? a.tags.some(t => typeof t === 'string' && t.toLowerCase().includes(cleanQ)) 
        : false;
      return a.title.toLowerCase().includes(cleanQ) || 
             a.excerpt.toLowerCase().includes(cleanQ) || 
             a.categoryLabel.toLowerCase().includes(cleanQ) ||
             tagMatch;
    });

    if (matches.length === 0) {
      searchResults.innerHTML = `
        <div style="padding: 24px; text-align: center; color: var(--ctl-text-light);">
          No technical guides found matching "<strong>${escapeHtml(query)}</strong>".
        </div>
      `;
    } else {
      searchResults.innerHTML = matches.map(a => `
        <div class="ctl-search-item" onclick="closeSearch(); openArticleModal(${a.id});">
          <div style="display: flex; gap: 8px; align-items: center; margin-bottom: 4px;">
            <span class="ctl-badge-pill ${a.badgeClass}" style="font-size: 0.65rem; padding: 2px 8px;">${a.categoryLabel}</span>
            <span style="font-size: 0.75rem; color: #94A3B8;">${a.readTime}</span>
          </div>
          <h4>${a.title}</h4>
          <p>${a.excerpt}</p>
        </div>
      `).join('');
    }
  }

  if (searchInput) {
    searchInput.addEventListener('input', (e) => {
      performSearch(e.target.value);
    });
  }

  if (searchOverlay) {
    searchOverlay.addEventListener('click', (e) => {
      if (e.target === searchOverlay) {
        closeSearch();
      }
    });
  }
}

/* ==========================================================================
   6. Mobile Menu Drawer
   ========================================================================== */
function initMobileDrawer() {
  const drawer = document.getElementById('mobile-drawer');

  window.openMobileDrawer = function() {
    if (drawer) drawer.classList.add('open');
  };

  window.closeMobileDrawer = function() {
    if (drawer) drawer.classList.remove('open');
  };
}
